cat > kumo.service <<EOF
[Unit]
Description=Kumo Anti-DDoS Service
After=network.target

[Service]
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/dotnet $(pwd)/Kumo.dll
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

sudo cp kumo.service /lib/systemd/system
rm kumo.service

sudo systemctl daemon-reload 
sudo systemctl enable kumo

rm config.json
dotnet Kumo.dll

echo "Edit your config.json before rebooting the server!"
echo "To start Kumo service after editing config.json use: service kumo start"